import React, { useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import EmotionRecognition from './components/EmotionRecognition';

const App: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <ThemeProvider>
      <Layout>
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
          <EmotionRecognition onModelLoaded={() => setIsLoaded(true)} />
        </div>
      </Layout>
    </ThemeProvider>
  );
};

export default App;