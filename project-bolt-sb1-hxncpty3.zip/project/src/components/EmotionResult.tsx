import React from 'react';
import { motion } from 'framer-motion';
import { EmotionResult as EmotionResultType } from '../types';

interface EmotionResultProps {
  emotions: EmotionResultType[];
  isVisible: boolean;
}

const EmotionResult: React.FC<EmotionResultProps> = ({ emotions, isVisible }) => {
  if (!isVisible || emotions.length === 0) {
    return null;
  }
  
  // Get the top emotion (highest probability)
  const topEmotion = emotions[0];
  
  // Emoji mapping for emotions
  const emotionEmojis: { [key: string]: string } = {
    happy: '😊',
    sad: '😢',
    angry: '😠',
    fearful: '😨',
    surprised: '😮',
    neutral: '😐'
  };
  
  // Get color based on emotion
  const getEmotionColor = (emotion: string): string => {
    const colors: { [key: string]: string } = {
      happy: 'text-happy bg-happy/10 border-happy/20',
      sad: 'text-sad bg-sad/10 border-sad/20',
      angry: 'text-angry bg-angry/10 border-angry/20',
      fearful: 'text-fearful bg-fearful/10 border-fearful/20',
      surprised: 'text-surprised bg-surprised/10 border-surprised/20',
      neutral: 'text-neutral-emotion bg-neutral-emotion/10 border-neutral-emotion/20',
    };
    
    return colors[emotion] || 'text-neutral bg-neutral/10 border-neutral/20';
  };
  
  // Format probability as percentage
  const formatProbability = (probability: number): string => {
    return `${(probability * 100).toFixed(1)}%`;
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-panel p-4"
    >
      <h2 className="text-xl font-bold mb-3">Emotion Analysis</h2>
      
      <div className="mb-6">
        <motion.div
          initial={{ scale: 0.9 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5 }}
          className={`flex items-center p-4 rounded-lg border ${getEmotionColor(topEmotion.emotion)}`}
        >
          <div className="text-4xl mr-4">{emotionEmojis[topEmotion.emotion]}</div>
          <div>
            <h3 className="text-lg font-semibold capitalize">{topEmotion.emotion}</h3>
            <p className="text-foreground/70">
              Confidence: {formatProbability(topEmotion.probability)}
            </p>
          </div>
        </motion.div>
      </div>
      
      <div className="space-y-2">
        <h3 className="text-md font-semibold">All Detected Emotions</h3>
        {emotions.map((emotion, index) => (
          <motion.div
            key={emotion.emotion}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            className="flex items-center justify-between p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <div className="flex items-center">
              <span className="mr-2">{emotionEmojis[emotion.emotion]}</span>
              <span className="capitalize">{emotion.emotion}</span>
            </div>
            <div className="text-foreground/70">{formatProbability(emotion.probability)}</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default EmotionResult;