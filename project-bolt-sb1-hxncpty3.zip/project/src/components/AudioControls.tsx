import React from 'react';
import { Mic, Square, RefreshCcw, Loader2, Play, Volume2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { RecordingState } from '../types';

interface AudioControlsProps {
  recordingState: RecordingState;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onResetRecording: () => void;
  onPlayAudio: () => void;
  audioUrl: string | null;
  isModelLoaded: boolean;
  error: string | null;
}

const AudioControls: React.FC<AudioControlsProps> = ({
  recordingState,
  onStartRecording,
  onStopRecording,
  onResetRecording,
  onPlayAudio,
  audioUrl,
  isModelLoaded,
  error
}) => {
  const isRecording = recordingState === RecordingState.RECORDING;
  const isProcessing = recordingState === RecordingState.PROCESSING;
  const isInactive = recordingState === RecordingState.INACTIVE;
  
  const recordButtonVariants = {
    idle: { scale: 1 },
    recording: { scale: [1, 1.1, 1], transition: { repeat: Infinity, duration: 2 } }
  };
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-panel p-4 flex flex-col items-center"
    >
      {error && (
        <div className="bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-2 rounded-md text-sm mb-4 w-full">
          {error}
        </div>
      )}
      
      <div className="flex flex-wrap justify-center gap-4">
        {isInactive && !audioUrl && (
          <motion.button
            variants={recordButtonVariants}
            animate="idle"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onStartRecording}
            disabled={!isModelLoaded || isProcessing}
            className={`flex items-center justify-center gap-2 px-6 py-3 rounded-full 
              ${isModelLoaded ? 'bg-primary hover:bg-primary/90' : 'bg-neutral/30'} 
              text-white font-medium transition-colors`}
          >
            <Mic size={18} />
            Start Recording
          </motion.button>
        )}
        
        {isRecording && (
          <motion.button
            variants={recordButtonVariants}
            animate="recording"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onStopRecording}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-full 
              bg-red-500 hover:bg-red-600 text-white font-medium transition-colors"
          >
            <Square size={18} />
            Stop Recording
          </motion.button>
        )}
        
        {isProcessing && (
          <button
            disabled
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-full 
              bg-neutral-500 text-white font-medium transition-colors"
          >
            <Loader2 size={18} className="animate-spin" />
            Processing...
          </button>
        )}
        
        {audioUrl && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onPlayAudio}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-full 
              bg-secondary hover:bg-secondary/90 text-white font-medium transition-colors"
          >
            <Play size={18} />
            Play Recording
          </motion.button>
        )}
        
        {!isInactive && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onResetRecording}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-full 
              bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 
              text-slate-700 dark:text-slate-200 font-medium transition-colors"
          >
            <RefreshCcw size={18} />
            Reset
          </motion.button>
        )}
      </div>
      
      {!isModelLoaded && (
        <div className="mt-4 flex items-center gap-2 text-neutral text-sm">
          <Loader2 size={14} className="animate-spin" />
          Loading emotion recognition model...
        </div>
      )}
      
      {audioUrl && (
        <audio id="audio-playback" src={audioUrl} className="hidden" />
      )}
    </motion.div>
  );
};

export default AudioControls;