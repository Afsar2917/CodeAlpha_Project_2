import React, { useState, useEffect, useCallback } from 'react';
import { useAudioRecorder } from '../hooks/useAudioRecorder';
import { useFeatureExtraction } from '../hooks/useFeatureExtraction';
import { useEmotionModel } from '../hooks/useEmotionModel';
import { EmotionResult, RecordingState } from '../types';
import AudioWaveform from './AudioWaveform';
import AudioControls from './AudioControls';
import EmotionChart from './EmotionChart';
import ResultDisplay from './EmotionResult';
import { motion } from 'framer-motion';

interface EmotionRecognitionProps {
  onModelLoaded?: () => void;
}

const EmotionRecognition: React.FC<EmotionRecognitionProps> = ({ onModelLoaded }) => {
  const [emotionResults, setEmotionResults] = useState<EmotionResult[]>([]);
  const [processingError, setProcessingError] = useState<string | null>(null);
  
  const { 
    audioData, 
    audioUrl, 
    recordingState,
    startRecording,
    stopRecording,
    resetRecording,
    analyserNode,
    error: audioError
  } = useAudioRecorder();
  
  const {
    extractFeaturesFromAudio,
    error: featureError
  } = useFeatureExtraction();
  
  const {
    predictEmotion,
    isModelLoaded,
    error: modelError
  } = useEmotionModel(onModelLoaded);
  
  const isRecording = recordingState === RecordingState.RECORDING;
  
  // Process audio after recording stops
  useEffect(() => {
    const processAudio = async () => {
      if (audioData && recordingState === RecordingState.PROCESSING) {
        try {
          setProcessingError(null);
          
          // Extract features
          const features = await extractFeaturesFromAudio(audioData);
          
          // Predict emotion
          const results = await predictEmotion(features);
          
          setEmotionResults(results);
        } catch (err) {
          console.error("Error processing audio:", err);
          setProcessingError(err instanceof Error ? err.message : 'Unknown error occurred');
        } finally {
          // Set to inactive after processing
          resetRecording();
        }
      }
    };
    
    processAudio();
  }, [audioData, recordingState, extractFeaturesFromAudio, predictEmotion, resetRecording]);
  
  // Combine all errors
  const error = audioError || featureError || modelError || processingError;
  
  // Handle playing audio
  const handlePlayAudio = useCallback(() => {
    if (audioUrl) {
      const audioElement = document.getElementById('audio-playback') as HTMLAudioElement;
      if (audioElement) {
        audioElement.play();
      }
    }
  }, [audioUrl]);
  
  return (
    <div className="w-full max-w-4xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold text-foreground mb-2">
          Speech Emotion Recognition
        </h1>
        <p className="text-foreground/70 max-w-2xl mx-auto">
          This application uses deep learning to analyze the emotional tone of your voice.
          Speak into your microphone, and we'll identify whether you sound happy, sad, angry, or something else.
        </p>
      </motion.div>
      
      <div className="space-y-6">
        <AudioWaveform analyserNode={analyserNode} isRecording={isRecording} />
        
        <AudioControls
          recordingState={recordingState}
          onStartRecording={startRecording}
          onStopRecording={stopRecording}
          onResetRecording={resetRecording}
          onPlayAudio={handlePlayAudio}
          audioUrl={audioUrl}
          isModelLoaded={isModelLoaded}
          error={error}
        />
        
        {emotionResults.length > 0 && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            <ResultDisplay emotions={emotionResults} isVisible={emotionResults.length > 0} />
            <EmotionChart emotions={emotionResults} />
          </motion.div>
        )}
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="glass-panel p-4 text-sm"
        >
          <h3 className="font-semibold mb-2">How it works</h3>
          <p className="text-foreground/70">
            This demo extracts audio features (MFCC, energy, spectral characteristics) from your speech
            and feeds them into a deep learning model trained to recognize emotional patterns.
            The model analyzes these patterns to predict the emotion expressed in your voice.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default EmotionRecognition;