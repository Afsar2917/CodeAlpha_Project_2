import React from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { EmotionResult } from '../types';
import { motion } from 'framer-motion';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

interface EmotionChartProps {
  emotions: EmotionResult[];
}

const EmotionChart: React.FC<EmotionChartProps> = ({ emotions }) => {
  // Get emotion colors based on emotion name
  const getEmotionColor = (emotion: string, opacity: number = 1): string => {
    const colors: { [key: string]: string } = {
      happy: `rgba(var(--happy), ${opacity})`,
      sad: `rgba(var(--sad), ${opacity})`,
      angry: `rgba(var(--angry), ${opacity})`,
      fearful: `rgba(var(--fearful), ${opacity})`,
      surprised: `rgba(var(--surprised), ${opacity})`,
      neutral: `rgba(var(--neutral-emotion), ${opacity})`,
    };
    
    return colors[emotion] || `rgba(var(--neutral), ${opacity})`;
  };
  
  const chartData = {
    labels: emotions.map(e => e.emotion),
    datasets: [
      {
        label: 'Probability',
        data: emotions.map(e => e.probability * 100), // Convert to percentage
        backgroundColor: emotions.map(e => getEmotionColor(e.emotion, 0.7)),
        borderColor: emotions.map(e => getEmotionColor(e.emotion, 1)),
        borderWidth: 1,
      },
    ],
  };
  
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        title: {
          display: true,
          text: 'Probability (%)',
        },
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.dataset.label}: ${context.raw.toFixed(2)}%`;
          }
        }
      }
    },
  };

  if (emotions.length === 0) {
    return (
      <div className="h-64 glass-panel flex items-center justify-center">
        <p className="text-neutral-500">No emotion data available</p>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="h-64 glass-panel p-4"
    >
      <Bar data={chartData} options={options} />
    </motion.div>
  );
};

export default EmotionChart;