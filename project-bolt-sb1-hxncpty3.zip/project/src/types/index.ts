export type Emotion = 
  | 'happy' 
  | 'sad' 
  | 'angry' 
  | 'fearful' 
  | 'surprised' 
  | 'neutral';

export interface EmotionResult {
  emotion: Emotion;
  probability: number;
}

export interface RecordingData {
  id: string;
  timestamp: Date;
  audioUrl: string;
  duration: number;
  emotions: EmotionResult[];
}

export interface AudioFeatures {
  mfcc: number[];
  rms: number;
  zcr: number;
  spectralCentroid: number;
  spectralFlatness: number;
  energy: number;
}

export enum RecordingState {
  INACTIVE = 'inactive',
  RECORDING = 'recording',
  PROCESSING = 'processing',
}