import { useState, useEffect, useRef, useCallback } from 'react';
import * as tf from '@tensorflow/tfjs';
import { EmotionResult, AudioFeatures, Emotion } from '../types';

interface EmotionModelHook {
  predictEmotion: (audioFeatures: AudioFeatures[]) => Promise<EmotionResult[]>;
  isModelLoaded: boolean;
  isProcessing: boolean;
  loadModel: () => Promise<void>;
  error: string | null;
}

const EMOTIONS: Emotion[] = ['happy', 'sad', 'angry', 'fearful', 'surprised', 'neutral'];

export const useEmotionModel = (onModelLoaded?: () => void): EmotionModelHook => {
  const [isModelLoaded, setIsModelLoaded] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const modelRef = useRef<tf.LayersModel | null>(null);

  // Function to create a simple model when no pre-trained model is available
  const createDummyModel = async (): Promise<tf.LayersModel> => {
    const model = tf.sequential();
    
    // Input shape: [timesteps, features]
    model.add(tf.layers.dense({
      units: 64,
      activation: 'relu',
      inputShape: [13], // Assuming we're using 13 MFCC coefficients
    }));
    
    model.add(tf.layers.dropout({ rate: 0.5 }));
    
    model.add(tf.layers.dense({
      units: 32,
      activation: 'relu',
    }));
    
    model.add(tf.layers.dense({
      units: EMOTIONS.length,
      activation: 'softmax',
    }));
    
    model.compile({
      optimizer: 'adam',
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy'],
    });
    
    return model;
  };

  // Load the model
  const loadModel = useCallback(async () => {
    try {
      setError(null);
      
      // In a real application, we would load a pre-trained model:
      // const model = await tf.loadLayersModel('path/to/model.json');
      
      // For demo purposes, we'll create a simple model
      console.log("Loading emotion recognition model...");
      const model = await createDummyModel();
      console.log("Model created successfully");
      
      modelRef.current = model;
      setIsModelLoaded(true);
      
      if (onModelLoaded) {
        onModelLoaded();
      }
    } catch (err) {
      console.error("Error loading model:", err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred while loading model');
    }
  }, [onModelLoaded]);

  // Load model on component mount
  useEffect(() => {
    loadModel();
    
    // Cleanup
    return () => {
      if (modelRef.current) {
        try {
          // Dispose of tensors to prevent memory leaks
          modelRef.current.dispose();
        } catch (err) {
          console.error("Error disposing model:", err);
        }
      }
    };
  }, [loadModel]);

  // Function to predict emotion from audio features
  const predictEmotion = async (audioFeatures: AudioFeatures[]): Promise<EmotionResult[]> => {
    setIsProcessing(true);
    setError(null);
    
    try {
      if (!modelRef.current) {
        throw new Error("Model not loaded");
      }
      
      // Aggregate features or use a window of features
      // For simplicity, we'll use the mean of all MFCC features
      const aggregatedMfcc = audioFeatures.reduce((acc, feature) => {
        feature.mfcc.forEach((val, idx) => {
          acc[idx] = (acc[idx] || 0) + val / audioFeatures.length;
        });
        return acc;
      }, Array(13).fill(0));
      
      // Convert to tensor
      const inputTensor = tf.tensor2d([aggregatedMfcc]);
      
      // Make prediction
      const prediction = modelRef.current.predict(inputTensor) as tf.Tensor;
      
      // Get probabilities
      const probabilities = await prediction.data();
      
      // Clean up tensors
      inputTensor.dispose();
      prediction.dispose();
      
      // Map probabilities to emotions
      const results: EmotionResult[] = Array.from(probabilities).map((prob, idx) => ({
        emotion: EMOTIONS[idx],
        probability: prob
      }));
      
      // Sort by probability (descending)
      return results.sort((a, b) => b.probability - a.probability);
    } catch (err) {
      console.error("Error predicting emotion:", err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred during prediction');
      return [];
    } finally {
      setIsProcessing(false);
    }
  };

  return {
    predictEmotion,
    isModelLoaded,
    isProcessing,
    loadModel,
    error
  };
};