import { useState, useEffect, useRef, useCallback } from 'react';
import { RecordingState } from '../types';

interface AudioRecorderHook {
  audioData: Blob | null;
  audioUrl: string | null;
  recordingState: RecordingState;
  startRecording: () => Promise<void>;
  stopRecording: () => void;
  resetRecording: () => void;
  mediaRecorder: MediaRecorder | null;
  audioContext: AudioContext | null;
  analyserNode: AnalyserNode | null;
  audioStream: MediaStream | null;
  error: string | null;
}

export const useAudioRecorder = (): AudioRecorderHook => {
  const [recordingState, setRecordingState] = useState<RecordingState>(RecordingState.INACTIVE);
  const [audioData, setAudioData] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // Cleanup function for audio resources
  const cleanupAudio = useCallback(() => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach(track => track.stop());
      audioStreamRef.current = null;
    }
    
    if (audioContextRef.current) {
      if (audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
      audioContextRef.current = null;
    }
    
    mediaRecorderRef.current = null;
    analyserNodeRef.current = null;
    chunksRef.current = [];
  }, [audioUrl]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      cleanupAudio();
    };
  }, [cleanupAudio]);

  const startRecording = async () => {
    try {
      cleanupAudio();
      setError(null);
      
      // Get audio stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;
      
      // Create audio context and analyzer
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioContext;
      
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 2048;
      analyserNodeRef.current = analyser;
      
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      
      // Set up media recorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/wav' });
        const url = URL.createObjectURL(audioBlob);
        
        setAudioData(audioBlob);
        setAudioUrl(url);
        setRecordingState(RecordingState.PROCESSING);
      };
      
      chunksRef.current = [];
      mediaRecorder.start();
      setRecordingState(RecordingState.RECORDING);
    } catch (err) {
      console.error('Error starting recording:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      setRecordingState(RecordingState.INACTIVE);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recordingState === RecordingState.RECORDING) {
      mediaRecorderRef.current.stop();
      
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(track => track.stop());
      }
    }
  };

  const resetRecording = () => {
    cleanupAudio();
    setAudioData(null);
    setAudioUrl(null);
    setRecordingState(RecordingState.INACTIVE);
    setError(null);
  };

  return {
    audioData,
    audioUrl,
    recordingState,
    startRecording,
    stopRecording,
    resetRecording,
    mediaRecorder: mediaRecorderRef.current,
    audioContext: audioContextRef.current,
    analyserNode: analyserNodeRef.current,
    audioStream: audioStreamRef.current,
    error
  };
};