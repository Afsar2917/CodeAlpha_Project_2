import { useEffect, useState, useRef } from 'react';
import Meyda from 'meyda';
import { AudioFeatures } from '../types';

interface FeatureExtractionHook {
  extractFeaturesFromAudio: (audioBlob: Blob) => Promise<AudioFeatures[]>;
  features: AudioFeatures[];
  isProcessing: boolean;
  error: string | null;
}

export const useFeatureExtraction = (): FeatureExtractionHook => {
  const [features, setFeatures] = useState<AudioFeatures[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    return () => {
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    };
  }, []);

  const extractFeaturesFromAudio = async (audioBlob: Blob): Promise<AudioFeatures[]> => {
    setIsProcessing(true);
    setError(null);
    
    try {
      // Create a new audio context
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioContext;
      
      // Convert blob to arrayBuffer
      const arrayBuffer = await audioBlob.arrayBuffer();
      
      // Decode the audio data
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      
      // Extract features using Meyda
      const bufferSize = 512;
      const hopSize = 256;
      const extractedFeatures: AudioFeatures[] = [];
      
      const numFrames = Math.floor((audioBuffer.length - bufferSize) / hopSize) + 1;
      
      for (let i = 0; i < numFrames; i++) {
        const startIndex = i * hopSize;
        const frame = new Float32Array(bufferSize);
        
        // Get the frame data from the audio buffer (only use first channel)
        for (let j = 0; j < bufferSize && startIndex + j < audioBuffer.length; j++) {
          frame[j] = audioBuffer.getChannelData(0)[startIndex + j];
        }
        
        // Calculate features directly using Meyda.extract without creating an analyzer
        const frameFeatures = Meyda.extract(
          ['mfcc', 'rms', 'zcr', 'spectralCentroid', 'spectralFlatness', 'energy'],
          frame
        );
        
        extractedFeatures.push({
          mfcc: frameFeatures.mfcc as number[],
          rms: frameFeatures.rms as number,
          zcr: frameFeatures.zcr as number,
          spectralCentroid: frameFeatures.spectralCentroid as number,
          spectralFlatness: frameFeatures.spectralFlatness as number,
          energy: frameFeatures.energy as number
        });
      }
      
      setFeatures(extractedFeatures);
      return extractedFeatures;
    } catch (err) {
      console.error('Error extracting features:', err);
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsProcessing(false);
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close();
      }
    }
  };
  
  return {
    extractFeaturesFromAudio,
    features,
    isProcessing,
    error
  };
};