/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: 'rgb(var(--background) / <alpha-value>)',
        foreground: 'rgb(var(--foreground) / <alpha-value>)',
        primary: 'rgb(var(--primary) / <alpha-value>)',
        secondary: 'rgb(var(--secondary) / <alpha-value>)',
        accent: 'rgb(var(--accent) / <alpha-value>)',
        neutral: 'rgb(var(--neutral) / <alpha-value>)',
        happy: 'rgb(var(--happy) / <alpha-value>)',
        sad: 'rgb(var(--sad) / <alpha-value>)',
        angry: 'rgb(var(--angry) / <alpha-value>)',
        fearful: 'rgb(var(--fearful) / <alpha-value>)',
        surprised: 'rgb(var(--surprised) / <alpha-value>)',
        'neutral-emotion': 'rgb(var(--neutral-emotion) / <alpha-value>)',
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce-slow': 'bounce 2s infinite',
        'wave': 'wave 1s ease-in-out infinite',
      },
      keyframes: {
        wave: {
          '0%, 100%': {
            transform: 'scaleY(0.5)'
          },
          '50%': {
            transform: 'scaleY(1.0)'
          },
        },
      },
    },
  },
  plugins: [],
};